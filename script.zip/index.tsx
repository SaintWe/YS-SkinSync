import { Button, HStack, List, Navigation, NavigationStack, Path, Script, Section, Spacer, Text, VStack } from 'scripting'
import { useEffect, useRef, useState } from 'scripting'
import { SettingsPage } from './components/settings-page'
import { getCurrentSettings } from './utils/skinSync-service'

// 同步日志类型
type SyncLog = {
  time: string
  action: string
  path: string
  status: 'success' | 'error'
  message?: string
}

// 文件变更事件类型
type FileChangeEvent = {
  action: 'update' | 'delete' | 'create_dir' | 'sync_start' | 'sync_complete' | 'sync_error'
  path: string
  content: string | null
  isDir: boolean
}

/**
 * 主页面
 */
const Main = () => {
  const dismiss = Navigation.useDismiss()

  // 状态管理
  const [connected, setConnected] = useState(false)
  const [connecting, setConnecting] = useState(false)
  const [syncing, setSyncing] = useState(false) // 全量同步中
  const [logs, setLogs] = useState<SyncLog[]>([])
  const [targetPath, setTargetPath] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string>('')

  // WebSocket 引用
  const wsRef = useRef<WebSocket | null>(null)
  // 使用 ref 存储目标路径，避免闭包问题
  const targetPathRef = useRef<string | null>(null)
  // 日志缓冲区
  const logsBufferRef = useRef<SyncLog[]>([])
  const lastUpdateRef = useRef(0)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // 刷新日志缓冲区
  const flushLogs = () => {
    if (logsBufferRef.current.length === 0) return

    const newLogs = [...logsBufferRef.current]
    logsBufferRef.current = [] // 清空缓冲区
    lastUpdateRef.current = Date.now()

    if (timerRef.current) {
      clearTimeout(timerRef.current)
      timerRef.current = null
    }

    setLogs(prev => {
      return [...newLogs.reverse(), ...prev].slice(0, 500)
    })
  }

  // 组件卸载时清理定时器
  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])

  // 添加日志
  const addLog = (action: string, path: string, status: 'success' | 'error', message?: string) => {
    const now = new Date()
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`

    // 将日志添加到缓冲区
    logsBufferRef.current.push({
      time: timeStr,
      action,
      path,
      status,
      message
    })

    // 智能节流更新
    const currentTime = Date.now()
    if (currentTime - lastUpdateRef.current > 200) {
      // 如果距离上次更新超过 200ms，立即更新
      flushLogs()
    } else {
      // 否则延迟更新
      if (!timerRef.current) {
        timerRef.current = setTimeout(flushLogs, 200)
      }
    }
  }

  // 处理文件同步
  const handleFileSync = async (event: FileChangeEvent) => {
    // 处理同步控制消息
    if (event.action === 'sync_start') {
      setSyncing(true)
      addLog('全量同步', '开始', 'success', '正在同步所有文件...')
      return
    }

    if (event.action === 'sync_complete') {
      setSyncing(false)
      addLog('全量同步', '完成', 'success', '所有文件已同步完成')
      return
    }

    if (event.action === 'sync_error') {
      setSyncing(false)
      addLog('全量同步', '失败', 'error', event.content || '未知错误')
      return
    }

    // 检查目标路径 - 使用 ref 获取最新值
    const currentTargetPath = targetPathRef.current
    if (!currentTargetPath) {
      addLog(event.action, event.path, 'error', '未设置目标目录')
      return
    }

    try {
      const fullPath = Path.join(currentTargetPath, event.path)

      if (event.action === 'delete') {
        // 删除文件或目录
        addLog('删除', event.path, 'success')
        if (await FileManager.exists(fullPath)) {
          await FileManager.remove(fullPath)
        }
      } else if (event.action === 'create_dir') {
        // 创建目录
        addLog('创建目录', event.path, 'success')
        if (!await FileManager.exists(fullPath)) {
          await FileManager.createDirectory(fullPath, true)
        }
      } else if (event.action === 'update') {
        // 更新或创建文件
        if (event.content !== null) {
          addLog('更新文件', event.path, 'success')

          // 确保父目录存在
          const parentDir = Path.dirname(fullPath)
          if (!await FileManager.exists(parentDir)) {
            await FileManager.createDirectory(parentDir, true)
          }

          // 写入文件
          await FileManager.writeAsString(fullPath, event.content, 'utf-8')
        }
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error)
      addLog(event.action, event.path, 'error', errorMsg)
      console.error('文件同步失败:', error)
    }
  }

  // 连接 WebSocket
  const connect = () => {
    if (wsRef.current) {
      return // 已经连接
    }

    // 检查文件书签
    if (!FileManager.bookmarkExists(getCurrentSettings().bookmark)) {
      setErrorMessage(`文件书签 "${getCurrentSettings().bookmark}" 不存在，请先在"文件书签"工具中创建`)
      return
    }

    const bookmarkedPath = FileManager.bookmarkedPath(getCurrentSettings().bookmark)
    if (!bookmarkedPath) {
      setErrorMessage('无法获取书签路径')
      return
    }

    // 同时更新 state 和 ref
    setTargetPath(bookmarkedPath)
    targetPathRef.current = bookmarkedPath
    setConnecting(true)
    setErrorMessage('')

    try {
      const ws = new WebSocket(getCurrentSettings().wsUrl)

      ws.onopen = () => {
        console.log('WebSocket 连接成功')
        setConnected(true)
        setConnecting(false)
        addLog('连接', '服务器', 'success', '已连接到服务器')
      }

      ws.onerror = (error) => {
        // 如果是手动断开（wsRef.current 为 null），则忽略错误
        if (wsRef.current === null) {
          return
        }
        console.error('WebSocket 错误:', error)
        setErrorMessage(`连接错误: ${error || '未知错误'}`)
        setConnecting(false)
        setConnected(false)
      }

      ws.onmessage = (message) => {
        try {
          // 解析消息
          const data = typeof message === 'string' ? JSON.parse(message) : JSON.parse(message.toString())
          console.log('收到消息:', data)

          // 处理文件变更事件
          handleFileSync(data as FileChangeEvent)
        } catch (error) {
          console.error('消息处理失败:', error)
          addLog('消息解析', '', 'error', '无法解析服务器消息')
        }
      }

      ws.onclose = (event) => {
        console.log('WebSocket 连接关闭:', event)

        // 检查是否为手动断开（手动断开时 wsRef.current 会被置为 null）
        const isManual = wsRef.current === null

        setConnected(false)
        setConnecting(false)
        wsRef.current = null

        let message = '连接已关闭'
        if (isManual) {
          message = '已断开连接'
        } else {
          // 尝试从事件中获取原因
          // 注意：Scripting 环境下的 WebSocket CloseEvent 可能与标准不同，做防御性处理
          if (event && typeof event === 'object') {
            // @ts-ignore
            message = event.reason || '服务器断开连接'
          } else if (typeof event === 'string') {
            message = event
          } else {
            message = '服务器断开连接'
          }
        }

        addLog('断开', '服务器', 'success', message)
      }

      wsRef.current = ws
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error)
      setErrorMessage(`连接失败: ${errorMsg}`)
      setConnecting(false)
      console.error('WebSocket 连接失败:', error)
    }
  }

  // 断开连接
  const disconnect = () => {
    if (wsRef.current) {
      wsRef.current.close()
      wsRef.current = null
    }
  }

  // 请求全量同步
  const requestSyncAll = () => {
    if (!wsRef.current || !connected) {
      setErrorMessage('请先连接到服务器')
      return
    }
    try {
      wsRef.current.send(JSON.stringify({ action: 'sync_all' }))
      addLog('请求', '全量同步', 'success', '已发送全量同步请求')
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error)
      setErrorMessage(`请求失败: ${errorMsg}`)
    }
  }

  // 清空日志
  const clearLogs = () => {
    setLogs([])
  }

  // 组件卸载时关闭连接
  useEffect(() => {
    return () => {
      disconnect()
    }
  }, [])


  const [showChangelogSheet, setShowChangelogSheet] = useState(false)

  return (
    <NavigationStack>
      <List
        navigationTitle="皮肤文件同步"
        navigationBarTitleDisplayMode="large"
        sheet={{
          isPresented: showChangelogSheet,
          onChanged: setShowChangelogSheet,
          content: (
            <VStack presentationDragIndicator="visible" presentationDetents={[800, 'medium', 'large']} spacing={20} padding={20}>
              <Text font="headline">1. 创建文件书签</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                在"文件书签"工具中创建一个书签，指向要同步的目标皮肤目录
              </Text>
              <Text font="headline">2. 设置服务器地址和文件书签</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                在设置中设置服务器地址以及"文件书签"工具创建的书签名
              </Text>
              <Text font="headline">3. 启动服务器</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                在 PC/MAC 端的终端运行: bun ws.ts
              </Text>
              <Text font="headline">4. 连接服务器</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                点击"连接服务器"按钮建立连接
              </Text>
              <Text font="headline">5. 自动同步</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                PC/MAC 端监控的 skins 目录中的文件变更会自动同步到目标目录
              </Text>
              <Text font="headline">6. 前往元书</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                前往元书，点击重新加载你所修改的皮肤
              </Text>
            </VStack>
          )
        }}
        toolbar={{
          cancellationAction: <Button title="关闭" action={dismiss} />,
          primaryAction: (
            <Button
              title="设置"
              action={async () => {
                await Navigation.present({
                  element: <SettingsPage />,
                  modalPresentationStyle: 'pageSheet'
                })
              }}
            />
          ),
          topBarTrailing: [
            <Button
              title="GitHub"
              action={() => { Safari.openURL('https://github.com/SaintWe/YS-SkinSync') }}
            />,
            <Button
              title="使用教程"
              action={() => setShowChangelogSheet(true)}
            />
          ]
        }}
      >
        {/* 连接状态 */}
        <Section header={<Text font="headline">连接状态</Text>}>
          <HStack spacing={10} padding={10}>
            <Text font="headline">
              {connected ? '🟢 已连接' : connecting ? '🟡 连接中...' : '🔴 未连接'}
            </Text>
            <Spacer />
            <Text font="headline" foregroundStyle="secondaryLabel">
              {getCurrentSettings().wsUrl}
            </Text>
          </HStack>

          {targetPath ? (
            <VStack alignment="center" spacing={5}>
              <Text font="headline" foregroundStyle="secondaryLabel">
                目标路径: {targetPath}
              </Text>
            </VStack>
          ) : <></>}

          {errorMessage ? (
            <VStack padding={10} background="#ffebee" clipShape={{ type: 'rect', cornerRadius: 8 }}>
              <Text font="caption" foregroundStyle="#c62828">
                ⚠️ {errorMessage}
              </Text>
            </VStack>
          ) : <></>}

          <HStack spacing={10} padding={10}>
            {!connected ? (
              <Button
                title="连接服务器"
                action={connect}
                buttonStyle="automatic"
              />
            ) : <></>}
            {connected ? (
              <>
                <Button
                  title="断开连接"
                  action={disconnect}
                  buttonStyle="automatic"
                />
                <Spacer />
                <Button
                  title="前往元书"
                  action={() => {
                    disconnect()
                    Safari.openURL('hamster3://com.ihsiao.apps.hamster3/keyboardSkins')
                  }}
                  buttonStyle="automatic"
                />
                <Spacer />
                <Button
                  title={syncing ? "同步中..." : "全量同步"}
                  action={requestSyncAll}
                  buttonStyle="automatic"
                  disabled={syncing}
                />
              </>
            ) : <></>}
          </HStack>
        </Section>

        {/* 同步日志 */}
        <Section
          header={
            <HStack>
              <Text font="headline">同步日志</Text>
              {logs.length > 0 ? (
                <>
                  <Spacer />
                  <Button title="清空" action={clearLogs} buttonStyle="automatic" />
                </>
              ) : <></>}
            </HStack>
          }
        >
          {logs.length === 0 ? (
            <Text font="caption" foregroundStyle="secondaryLabel" padding={10}>
              暂无同步记录
            </Text>
          ) : (
            <VStack alignment="leading" spacing={5}>
              {logs.map((log, index) => (
                <HStack
                  key={index}
                  spacing={8}
                  padding={8}
                  background={
                    log.status === 'error'
                      ? 'rgba(244, 67, 54, 0.15)' // 红色半透明
                      : 'rgba(76, 175, 80, 0.15)' // 绿色半透明
                  }
                  clipShape={{ type: 'rect', cornerRadius: 6 }}
                >
                  <Text font="caption2" foregroundStyle="secondaryLabel" frame={{ width: 50 }}>
                    {log.time}
                  </Text>
                  <VStack alignment="leading" spacing={2}>
                    <HStack spacing={5}>
                      <Text font="caption" bold>
                        {log.status === 'success' ? '✓' : '✗'} {log.action}
                      </Text>
                      <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
                        {log.path}
                      </Text>
                    </HStack>
                    {log.message ? (
                      <Text font="caption2" foregroundStyle={log.status === 'error' ? 'red' : 'secondaryLabel'}>
                        {log.message}
                      </Text>
                    ) : <></>}
                  </VStack>
                  <Spacer />
                </HStack>
              ))}
            </VStack>
          )}
        </Section>
      </List>
    </NavigationStack>
  )
}

/**
 * 主函数
 */
const run = async (): Promise<void> => {
  await Navigation.present({
    element: <Main />,
    modalPresentationStyle: 'pageSheet'
  })
  Script.exit()
}

run()
