import { Button, HStack, List, Navigation, NavigationStack, Path, Script, Section, Spacer, Text, VStack } from 'scripting'
import { useEffect, useRef, useState } from 'scripting'
import { SettingsPage } from './components/settings-page'
import { getCurrentSettings } from './utils/skinSync-service'

// 同步日志类型
type SyncLog = {
  time: string
  action: string
  path: string
  status: 'success' | 'error'
  message?: string
}

// 文件变更事件类型
type FileChangeEvent = {
  action: 'update' | 'delete' | 'create_dir' | 'sync_start' | 'sync_complete' | 'sync_error'
  path: string
  content: string | null
  isDir: boolean
}

/**
 * 主页面
 */
const Main = () => {
  const dismiss = Navigation.useDismiss()

  // 状态管理
  const [connected, setConnected] = useState(false)
  const [connecting, setConnecting] = useState(false)
  const [syncing, setSyncing] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [logs, setLogs] = useState<SyncLog[]>([])
  const [targetPath, setTargetPath] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string>('')
  const [settings, setSettings] = useState(getCurrentSettings())

  // WebSocket 引用
  const wsRef = useRef<WebSocket | null>(null)
  // 使用 ref 存储目标路径，避免闭包问题
  const targetPathRef = useRef<string | null>(null)
  // 使用 ref 存储上传状态，避免闭包问题
  const uploadingRef = useRef(false)
  // 日志缓冲区
  const logsBufferRef = useRef<SyncLog[]>([])
  const lastUpdateRef = useRef(0)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // 刷新日志缓冲区
  const flushLogs = () => {
    if (logsBufferRef.current.length === 0) return

    const newLogs = [...logsBufferRef.current]
    logsBufferRef.current = [] // 清空缓冲区
    lastUpdateRef.current = Date.now()

    if (timerRef.current) {
      clearTimeout(timerRef.current)
      timerRef.current = null
    }

    setLogs(prev => {
      return [...newLogs.reverse(), ...prev].slice(0, 500)
    })
  }

  // 组件卸载时清理定时器
  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])

  // 添加日志
  const addLog = (action: string, path: string, status: 'success' | 'error', message?: string) => {
    const now = new Date()
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`

    // 将日志添加到缓冲区
    logsBufferRef.current.push({
      time: timeStr,
      action,
      path,
      status,
      message
    })

    // 智能节流更新
    const currentTime = Date.now()
    if (currentTime - lastUpdateRef.current > 200) {
      // 如果距离上次更新超过 200ms，立即更新
      flushLogs()
    } else {
      // 否则延迟更新
      if (!timerRef.current) {
        timerRef.current = setTimeout(flushLogs, 200)
      }
    }
  }

  // 处理文件同步
  const handleFileSync = async (event: FileChangeEvent) => {
    // 如果正在上传，忽略来自服务端的更新消息（防止回环）
    if (uploadingRef.current && (event.action === 'update' || event.action === 'create_dir' || event.action === 'delete')) {
      return
    }

    // 处理同步控制消息
    if (event.action === 'sync_start') {
      setSyncing(true)
      addLog('下载全部', '开始', 'success', '正在同步所有文件...')
      return
    }

    if (event.action === 'sync_complete') {
      console.log('收到 sync_complete，准备结束同步状态')
      // 延迟一点设置状态，确保 UI 能够正确响应
      setTimeout(() => {
        setSyncing(false)
      }, 100)
      addLog('下载全部', '完成', 'success', '所有文件已同步完成')
      return
    }

    if (event.action === 'sync_error') {
      setSyncing(false)
      addLog('下载全部', '失败', 'error', event.content || '未知错误')
      return
    }

    // 检查目标路径 - 使用 ref 获取最新值
    const currentTargetPath = targetPathRef.current
    if (!currentTargetPath) {
      addLog(event.action, event.path, 'error', '未设置目标目录')
      return
    }

    try {
      const fullPath = Path.join(currentTargetPath, event.path)

      if (event.action === 'delete') {
        // 删除文件或目录
        addLog('删除', event.path, 'success')
        if (await FileManager.exists(fullPath)) {
          await FileManager.remove(fullPath)
        }
      } else if (event.action === 'create_dir') {
        // 创建目录
        addLog('创建目录', event.path, 'success')
        if (!await FileManager.exists(fullPath)) {
          await FileManager.createDirectory(fullPath, true)
        }
      } else if (event.action === 'update') {
        // 更新或创建文件
        if (event.content !== null) {
          addLog('更新文件', event.path, 'success')

          // 确保父目录存在
          const parentDir = Path.dirname(fullPath)
          if (!await FileManager.exists(parentDir)) {
            await FileManager.createDirectory(parentDir, true)
          }

          // 写入文件
          await FileManager.writeAsString(fullPath, event.content, 'utf-8')
        }
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error)
      addLog(event.action, event.path, 'error', errorMsg)
      console.error('文件同步失败:', error)
    }
  }

  // 连接 WebSocket
  const connect = () => {
    // 如果已经连接或正在连接，且状态正常，则不重复连接
    if (wsRef.current && (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING)) {
      return
    }
    // 如果存在旧的已关闭连接，先清理
    if (wsRef.current) {
      wsRef.current = null
    }

    // 检查文件书签
    if (!FileManager.bookmarkExists(settings.bookmark)) {
      setErrorMessage(`文件书签 "${settings.bookmark}" 不存在，请先在"文件书签"工具中创建`)
      return
    }

    const bookmarkedPath = FileManager.bookmarkedPath(settings.bookmark)
    if (!bookmarkedPath) {
      setErrorMessage('无法获取书签路径')
      return
    }

    // 同时更新 state 和 ref
    setTargetPath(bookmarkedPath)
    targetPathRef.current = bookmarkedPath
    setConnecting(true)
    setErrorMessage('')

    try {
      const ws = new WebSocket(settings.wsUrl)

      ws.onopen = () => {
        console.log('WebSocket 连接成功')
        setConnected(true)
        setConnecting(false)
        addLog('连接', '服务器', 'success', '已连接到服务器')
      }

      ws.onerror = (error) => {
        // 如果是手动断开（wsRef.current 为 null），则忽略错误
        if (wsRef.current === null) {
          return
        }
        console.error('WebSocket 错误:', error)
        setErrorMessage(`连接错误: ${error || '未知错误'}`)
        setConnecting(false)
        setConnected(false)
        wsRef.current = null // 确保清理引用，允许重新连接
      }

      ws.onmessage = (message) => {
        try {
          // 解析消息
          const data = typeof message === 'string' ? JSON.parse(message) : JSON.parse(message.toString())
          console.log('收到消息:', data)

          // 处理文件变更事件
          handleFileSync(data as FileChangeEvent)
        } catch (error) {
          console.error('消息处理失败:', error)
          addLog('消息解析', '', 'error', '无法解析服务器消息')
        }
      }

      ws.onclose = (event) => {
        console.log('WebSocket 连接关闭:', event)

        // 检查是否为手动断开（手动断开时 wsRef.current 会被置为 null）
        const isManual = wsRef.current === null

        setConnected(false)
        setConnecting(false)
        wsRef.current = null

        let message = '连接已关闭'
        if (isManual) {
          message = '已断开连接'
        } else {
          // 尝试从事件中获取原因
          // 注意：Scripting 环境下的 WebSocket CloseEvent 可能与标准不同，做防御性处理
          if (event && typeof event === 'object') {
            // @ts-ignore
            message = event.reason || '服务器断开连接'
          } else if (typeof event === 'string') {
            message = event
          } else {
            message = '服务器断开连接'
          }
        }

        addLog('断开', '服务器', 'success', message)
      }

      wsRef.current = ws
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error)
      setErrorMessage(`连接失败: ${errorMsg}`)
      setConnecting(false)
      console.error('WebSocket 连接失败:', error)
    }
  }

  // 断开连接
  const disconnect = () => {
    if (wsRef.current) {
      wsRef.current.close()
      wsRef.current = null
    }
  }

  // 请求下载全部
  const requestSyncAll = () => {
    if (!wsRef.current || !connected) {
      setErrorMessage('请先连接到服务器')
      return
    }
    try {
      wsRef.current.send(JSON.stringify({ action: 'sync_all' }))
      addLog('请求', '下载全部', 'success', '已发送下载全部请求')
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error)
      setErrorMessage(`请求失败: ${errorMsg}`)
    }
  }

  // 上传全部文件
  const uploadAll = async () => {
    if (!wsRef.current || !connected) {
      setErrorMessage('请先连接到服务器')
      return
    }

    const currentTargetPath = targetPathRef.current
    if (!currentTargetPath) {
      setErrorMessage('未设置目标目录')
      return
    }

    setUploading(true)
    uploadingRef.current = true
    addLog('上传全部', '开始', 'success', '正在扫描并上传文件...')

    try {
      // 发送开始信号
      wsRef.current.send(JSON.stringify({ action: 'client_upload_start' }))

      // 递归扫描并发送
      const scanAndSend = async (dirPath: string, relPath: string) => {
        const items = await FileManager.readDirectory(dirPath)
        for (const item of items) {
          if (item === '.DS_Store') continue

          const itemPath = Path.join(dirPath, item)
          const itemRelPath = relPath ? Path.join(relPath, item) : item

          if (await FileManager.isDirectory(itemPath)) {
            // 发送目录创建消息
            wsRef.current?.send(JSON.stringify({
              action: 'create_dir',
              path: itemRelPath,
              isDir: true
            }))
            addLog('创建目录', itemRelPath, 'success')
            // 递归
            await scanAndSend(itemPath, itemRelPath)
          } else {
            // 发送文件内容
            const isBinary = await FileManager.isBinaryFile(itemPath)
            let content: string
            let encoding: 'utf-8' | 'base64'

            if (isBinary) {
              // 二进制文件：读取为 Data 并转换为 Base64
              const data = await FileManager.readAsData(itemPath)
              content = data.toBase64String()
              encoding = 'base64'
            } else {
              // 文本文件
              content = await FileManager.readAsString(itemPath)
              encoding = 'utf-8'
            }

            wsRef.current?.send(JSON.stringify({
              action: 'update',
              path: itemRelPath,
              content,
              encoding,
              isDir: false
            }))
            addLog('上传文件', itemRelPath, 'success')
          }
        }
      }

      await scanAndSend(currentTargetPath, '')

      // 发送完成信号
      wsRef.current.send(JSON.stringify({ action: 'client_upload_complete' }))

      // 延迟显示完成日志，让文件处理日志先渲染
      await new Promise(resolve => setTimeout(resolve, 500))
      addLog('上传全部', '完成', 'success', '所有文件已上传')
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error)
      addLog('上传全部', '失败', 'error', errorMsg)
    } finally {
      setUploading(false)
      uploadingRef.current = false
    }
  }

  // 清空日志
  const clearLogs = () => {
    setLogs([])
  }

  // 组件卸载时关闭连接
  useEffect(() => {
    return () => {
      disconnect()
    }
  }, [])

  const [showManualSheet, setShowManualSheet] = useState(false)
  const [showSettingsSheet, setShowSettingsSheet] = useState(false)

  // 在设置页面关闭时刷新设置
  useEffect(() => {
    if (!showSettingsSheet) {
      setSettings(getCurrentSettings())
    }
  }, [showSettingsSheet])

  return (
    <NavigationStack>
      <List
        navigationTitle="皮肤文件同步"
        navigationBarTitleDisplayMode="large"
        sheet={{
          isPresented: showManualSheet,
          onChanged: setShowManualSheet,
          content: (
            <VStack presentationDragIndicator="visible" presentationDetents={[800, 'medium', 'large']} spacing={20} padding={20}>
              <Text font="headline">1. 创建文件书签</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                在"文件书签"工具中创建一个书签，指向要同步的目标皮肤目录
              </Text>
              <Text font="headline">2. 设置服务器地址和文件书签</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                在设置中设置服务器地址以及"文件书签"工具创建的书签名
              </Text>
              <Text font="headline">3. 启动服务器</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                在 PC/MAC 端的终端运行: bun ws.ts
              </Text>
              <Text font="headline">4. 连接服务器</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                点击"连接服务器"按钮建立连接
              </Text>
              <Text font="headline">5. 自动同步</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                PC/MAC 端监控的 skin 目录中的文件变更会自动同步到目标目录
              </Text>
              <Text font="headline">6. 前往元书</Text>
              <Text font="caption" foregroundStyle="secondaryLabel">
                前往元书，点击重新加载你所修改的皮肤
              </Text>
            </VStack>
          )
        }}
        toolbar={{
          cancellationAction: <Button title="关闭" action={dismiss} />,
          primaryAction: (
            <Button
              title="设置"
              action={async () => {
                setShowSettingsSheet(true)
                await Navigation.present({
                  element: <SettingsPage />,
                  modalPresentationStyle: 'pageSheet'
                })
                setShowSettingsSheet(false)
              }}
            />
          ),
          topBarTrailing: [
            <Button
              key="github"
              title="GitHub"
              action={() => { Safari.openURL('https://github.com/SaintWe/YS-SkinSync') }}
            />,
            <Button
              key="tutorial"
              title="使用教程"
              action={() => setShowManualSheet(true)}
            />
          ]
        }}
      >
        {/* 连接状态 */}
        <Section header={<Text font="headline">连接状态</Text>}>
          <HStack spacing={10} padding={10}>
            <Text font="headline">
              {connected ? '🟢 已连接' : connecting ? '🟡 连接中...' : '🔴 未连接'}
            </Text>
            <Spacer />
            <Text font="headline" foregroundStyle="secondaryLabel">
              {settings.wsUrl}
            </Text>
          </HStack>

          {targetPath ? (
            <VStack alignment="center" spacing={5}>
              <Text font="headline" foregroundStyle="secondaryLabel">
                目标路径: {targetPath}
              </Text>
            </VStack>
          ) : <></>}

          {errorMessage ? (
            <VStack padding={10} background="#ffebee" clipShape={{ type: 'rect', cornerRadius: 8 }}>
              <Text font="caption" foregroundStyle="#c62828">
                ⚠️ {errorMessage}
              </Text>
            </VStack>
          ) : <></>}

          <HStack spacing={10} padding={10}>
            {!connected ? (
              <Button
                key="connect"
                title="连接服务器"
                action={connect}
                buttonStyle="borderedProminent"
              />
            ) : <></>}
            {connected ? (
              <>
                <Button
                  key="disconnect"
                  title="断开连接"
                  action={disconnect}
                  buttonStyle="bordered"
                />
                <Spacer />
                <Button
                  key="sync"
                  title={syncing ? "下载中..." : "下载全部"}
                  action={requestSyncAll}
                  buttonStyle="bordered"
                  disabled={syncing || uploading}
                />
                <Spacer />
                <Button
                  key="upload"
                  title={uploading ? "上传中..." : "上传全部"}
                  action={uploadAll}
                  buttonStyle="bordered"
                  disabled={syncing || uploading}
                />
              </>
            ) : <></>}
          </HStack>
        </Section>

        <Section>
          <Button
            key="open"
            title={settings.customButtonTitle || '未设定，请先设定按钮动作'}
            action={() => {
              disconnect()
              Safari.openURL(settings.customButtonUrl || '')
            }}
            buttonStyle="automatic"
          />
        </Section>

        {/* 同步日志 */}
        <Section
          header={
            <HStack>
              <Text font="headline">同步日志</Text>
              {logs.length > 0 ? (
                <>
                  <Spacer />
                  <Button title="清空" action={clearLogs} buttonStyle="automatic" />
                </>
              ) : <></>}
            </HStack>
          }
        >
          {logs.length === 0 ? (
            <Text font="caption" foregroundStyle="secondaryLabel" padding={10}>
              暂无同步记录
            </Text>
          ) : (
            <VStack alignment="leading" spacing={5}>
              {logs.map((log, index) => (
                <HStack
                  key={index}
                  spacing={8}
                  padding={8}
                  background={
                    log.status === 'error'
                      ? 'rgba(244, 67, 54, 0.15)' // 红色半透明
                      : 'rgba(76, 175, 80, 0.15)' // 绿色半透明
                  }
                  clipShape={{ type: 'rect', cornerRadius: 6 }}
                >
                  <Text font="caption2" foregroundStyle="secondaryLabel" frame={{ width: 50 }}>
                    {log.time}
                  </Text>
                  <VStack alignment="leading" spacing={2}>
                    <HStack spacing={5}>
                      <Text font="caption" bold>
                        {log.status === 'success' ? '✓' : '✗'} {log.action}
                      </Text>
                      <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
                        {log.path}
                      </Text>
                    </HStack>
                    {log.message ? (
                      <Text font="caption2" foregroundStyle={log.status === 'error' ? 'red' : 'secondaryLabel'}>
                        {log.message}
                      </Text>
                    ) : <></>}
                  </VStack>
                  <Spacer />
                </HStack>
              ))}
            </VStack>
          )}
        </Section>
      </List>
    </NavigationStack>
  )
}

/**
 * 主函数
 */
const run = async (): Promise<void> => {
  await Navigation.present({
    element: <Main />,
    modalPresentationStyle: 'pageSheet'
  })
  Script.exit()
}

run()
