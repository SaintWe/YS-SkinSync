import { Button, List, Navigation, NavigationStack, Section, Text, TextField, HStack } from 'scripting'
import { useState } from 'scripting'
import { getCurrentSettings, saveSettings } from '../utils/skinSync-service'

/**
 * 设置页面组件
 */
export const SettingsPage = () => {
  const dismiss = Navigation.useDismiss()
  const [currentSettings, setCurrentSettings] = useState(() => getCurrentSettings())

  // 更新设置的通用函数
  const updateSettings = (newSettings: any) => {
    setCurrentSettings(newSettings)
    const success = saveSettings(newSettings)
    if (!success) {
      console.error('保存设置失败')
    }
  }

  const [bookmark, setBookmark] = useState(currentSettings.bookmark ?? '')
  const handleBookmarkChange = (value: string) => {
    setBookmark(value)
    updateSettings({ ...currentSettings, bookmark: value })
  }


  const [wsUrl, setWsUrl] = useState(currentSettings.wsUrl ?? '')
  const handleWsUrlChange = (value: string) => {
    setWsUrl(value)
    updateSettings({ ...currentSettings, wsUrl: value })
  }

  const [customButtonTitle, setCustomButtonTitle] = useState(currentSettings.customButtonTitle ?? '')
  const handleCustomButtonTitleChange = (value: string) => {
    setCustomButtonTitle(value)
    updateSettings({ ...currentSettings, customButtonTitle: value })
  }

  const [customButtonUrl, setCustomButtonUrl] = useState(currentSettings.customButtonUrl ?? '')
  const handleCustomButtonUrlChange = (value: string) => {
    setCustomButtonUrl(value)
    updateSettings({ ...currentSettings, customButtonUrl: value })
  }

  return (
    <NavigationStack>
      <List
        navigationTitle="设置"
        navigationBarTitleDisplayMode="large"
        toolbar={{
          cancellationAction: <Button title="完成" action={dismiss} />
        }}
      >

        <Section
          header={<Text font="headline">目录书签名</Text>}
          footer={
            <Text font="footnote" foregroundStyle="secondaryLabel">
              在应用内『工具 -〉文件书签 -〉添加目录』{"\n"}
              书签名填写在这里，默认同步此目录
            </Text>
          }
        >
          <HStack>
            <TextField
              key={'path'}
              title="目录书签名"
              value={bookmark}
              onChanged={(value) => handleBookmarkChange(value)}
              prompt="请输入目录书签名"
              axis="vertical"
              lineLimit={1}
            />
          </HStack>
        </Section>

        <Section
          header={<Text font="headline">WebSocket地址</Text>}
          footer={
            <Text font="footnote" foregroundStyle="secondaryLabel">
              WebSocket地址
            </Text>
          }
        >
          <HStack>
            <TextField
              key={'wsUrl'}
              title="WebSocket地址"
              value={wsUrl}
              onChanged={(value) => handleWsUrlChange(value)}
              prompt="请输入WebSocket地址"
              axis="vertical"
              lineLimit={1}
            />
          </HStack>
        </Section>

        <Section
          header={<Text font="headline">自定义按钮</Text>}
        >
          <HStack>
            <TextField
              key={'customButtonTitle'}
              title="按钮标题"
              value={customButtonTitle}
              onChanged={(value) => handleCustomButtonTitleChange(value)}
              prompt="请输入按钮标题"
              axis="vertical"
              lineLimit={1}
            />
          </HStack>
        </Section>

        <Section
          header={<Text font="headline">自定义按钮URL</Text>}
        >
          <HStack>
            <TextField
              key={'customButtonUrl'}
              title="按钮URL"
              value={customButtonUrl}
              onChanged={(value) => handleCustomButtonUrlChange(value)}
              prompt="请输入按钮URL"
              axis="vertical"
              lineLimit={1}
            />
          </HStack>
        </Section>

      </List>
    </NavigationStack>
  )
}
